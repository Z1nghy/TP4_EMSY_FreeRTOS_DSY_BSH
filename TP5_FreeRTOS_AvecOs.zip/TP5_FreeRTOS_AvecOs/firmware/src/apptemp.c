/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    apptemp.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "apptemp.h"
#include "Mc32gestSpiLM70.h"
#include "semphr.h"
#include "queue.h"
#include "Mc32DriverLcd.h"



SemaphoreHandle_t xSemTemp;

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APPTEMP_DATA apptempData;
        
// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APPTEMP_Initialize ( void )

  Remarks:
    See prototype in apptemp.h.
 */
// D�clarer le s�maphore et la queue comme variables globales
SemaphoreHandle_t xSemTimer;   // lib�r� par l'ISR timer
QueueHandle_t     xQueueLcd;   // partag�e entre APPTEMP et APPLCD
void APPTEMP_Initialize(void)
{
    apptempData.state = APPTEMP_STATE_INIT;
}

void APPTEMP_Tasks(void)
{
    switch (apptempData.state)
    {
        case APPTEMP_STATE_INIT:
        {
            SPI_InitLM70();
            DRV_TMR0_Start();
            // Cr�er le s�maphore binaire
            xSemTimer = xSemaphoreCreateBinary();

            // Cr�er la queue : 10 messages de type APP_MSG
            xQueueLcd = xQueueCreate(10, sizeof(APP_MSG));

            apptempData.state = APPTEMP_STATE_SERVICE_TASKS;
            break;
        }

        case APPTEMP_STATE_SERVICE_TASKS:
        {
            APP_MSG msg;

//            BSP_LEDOff(BSP_LED_3); // debug : t�che en attente

            // Attente du s�maphore (bloquant, donn� par l'ISR timer toutes les 100ms)
            xSemaphoreTake(xSemTimer, portMAX_DELAY);
            BSP_LEDToggle(BSP_LED_3);
            

            // Lecture de la temp�rature brute via SPI
            msg.type    = MSG_TYPE_TEMP;
            msg.rawTemp = SPI_ReadRawTempLM70();

            // Envoi dans la queue (attente max 10 ticks si pleine)
            xQueueSend(xQueueLcd, &msg, 0U);
//            BSP_LEDOn(BSP_LED_3); // debug : t�che active
            break;
        }

        default:
            break;
    }
}

 

/*******************************************************************************
 End of File
 */
