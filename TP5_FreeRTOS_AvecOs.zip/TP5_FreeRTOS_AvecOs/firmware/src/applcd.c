/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    applcd.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "applcd.h"
#include "apptemp.h"
#include "Mc32gestSpiLM70.h"
#include "Mc32DriverLcd.h"

#include "queue.h"


// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APPLCD_DATA applcdData;


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APPLCD_Initialize ( void )

  Remarks:
    See prototype in applcd.h.
 */
extern QueueHandle_t     xQueueLcd;


void APPLCD_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    applcdData.state = APPLCD_STATE_INIT;

    
}


/******************************************************************************
  Function:
    void APPLCD_Tasks ( void )

  Remarks:
    See prototype in applcd.h.
 */

void APPLCD_Tasks(void)
{
    switch (applcdData.state)
    {
        case APPLCD_STATE_INIT:
        {
            lcd_init();  // init afficheur LCD
            lcd_bl_on();
            printf_lcd("EMSY TP5 FreeRTOS");
            applcdData.state = APPLCD_STATE_SERVICE_TASKS;
            break;
        }

        case APPLCD_STATE_SERVICE_TASKS:
        {
            APP_MSG msg;
            float   temperature;
            char    lcdBuf[17];
            uint8_t temp;
            uint8_t temp_digit;
            BSP_LEDToggle(BSP_LED_2); // debug

            // Attente bloquante d'un message dans la queue
            xQueueReceive(xQueueLcd, &msg, 0u);

            

            if (msg.type == MSG_TYPE_TEMP)
            {
                // Conversion valeur brute ? degr�s Celsius
                LM70_ConvRawToDeg(msg.rawTemp, &temperature);
                temperature = temperature *100;
                temp = temperature / 100;
                temp_digit = (int)temperature % 100;
                lcd_gotoxy(1,4);
                printf_lcd("Temp: %2d,%02d C", temp , temp_digit);  
            }
            else if (msg.type == MSG_TYPE_CHAR)
            {
                // Afficher le caract�re re�u sur la ligne 1
                sprintf(lcdBuf, "Char: %c        ", msg.character);
                lcd_gotoxy(1,3);
                printf_lcd(lcdBuf);
            }
            
            //BSP_LEDOn(BSP_LED_2); // debug
            break;
        }

        default:
            break;
    }
}
 

/*******************************************************************************
 End of File
 */
